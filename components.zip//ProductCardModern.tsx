import React, { useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import { ProductImageContainer } from './ProductImageContainer';
import { PriceTag } from './PriceTag';

export interface ProductCardModernProps {
  // Data
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image: string;
  storeName?: string;
  storeIcon?: string;
  
  // Event handlers
  onProductClick?: (id: string) => void;
  onStoreClick?: (storeId: string) => void;
  onAddToCart?: (id: string) => void;
}

export function ProductCardModern({
  id,
  title,
  price,
  originalPrice,
  image,
  storeName,
  storeIcon = '🏪',
  onProductClick,
  onStoreClick,
  onAddToCart
}: ProductCardModernProps) {
  const [isHovered, setIsHovered] = useState(false);

  const handleProductClick = () => {
    onProductClick?.(id);
  };

  const handleStoreClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onStoreClick?.(id);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart?.(id);
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-150 ease-in cursor-pointer hover:scale-[1.02] overflow-hidden group border border-gray-100 w-full"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleProductClick}
    >
      {/* Image Container */}
      <ProductImageContainer
        src={image}
        alt={title}
        aspectRatio="1:1"
        rounded="xl"
        overlay={
          <>
            {/* Cart Button - appears on hover */}
            <div 
              className={`absolute bottom-3 right-3 transition-all duration-200 ${
                isHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
              }`}
            >
              <button
                onClick={handleAddToCart}
                className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-purple-700 transition-colors"
              >
                <ShoppingCart className="w-4 h-4" />
              </button>
            </div>
          </>
        }
      />

      {/* Content */}
      <div className="p-3 space-y-2">
        {/* Store Info */}
        {storeName && (
          <button
            onClick={handleStoreClick}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <span className="text-xs">{storeIcon}</span>
            <span className="font-medium uppercase tracking-wide">{storeName}</span>
          </button>
        )}

        {/* Product Title */}
        <h3 className="font-medium line-clamp-2 leading-tight">
          {title}
        </h3>

        {/* Price Section */}
        <PriceTag 
          price={price}
          originalPrice={originalPrice}
          size="md"
          variant="default"
        />
      </div>
    </div>
  );
}

export default ProductCardModern;