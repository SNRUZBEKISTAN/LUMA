import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { FloatingBottomNav } from './FloatingBottomNav';
import { StickyActionBar } from './StickyActionBar';
import { ArrowLeft, Plus, Minus, Trash2, ShoppingBag } from 'lucide-react';

interface CartItem {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  quantity: number;
  image: string;
  size?: string;
  color?: string;
}

interface ShopCart {
  shopId: string;
  shopName: string;
  shopAvatar: string;
  isVerified: boolean;
  items: CartItem[];
  deliveryFee: number;
  freeDeliveryThreshold: number;
}

interface CartScreenProps {
  onBack: () => void;
  onCheckout: () => void;
  onTabChange: (tab: string) => void;
  activeTab: string;
}

export function CartScreen({ onBack, onCheckout, onTabChange, activeTab }: CartScreenProps) {
  const [shopCarts, setShopCarts] = React.useState<ShopCart[]>([
    {
      shopId: '1',
      shopName: 'Fashion Co',
      shopAvatar: '👗',
      isVerified: true,
      deliveryFee: 15000,
      freeDeliveryThreshold: 300000,
      items: [
        {
          id: '1',
          name: 'Элегантное платье с поясом',
          price: 250000,
          originalPrice: 350000,
          quantity: 1,
          image: 'https://images.unsplash.com/photo-1651047557884-49a4eb205f1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZHJlc3MlMjBmYXNoaW9ufGVufDF8fHx8MTc1NDg5MDM1OHww&ixlib=rb-4.1.0&q=80&w=1080',
          size: 'M',
          color: 'Черный'
        }
      ]
    },
    {
      shopId: '2',
      shopName: 'Jewelry',
      shopAvatar: '💍',
      isVerified: true,
      deliveryFee: 25000,
      freeDeliveryThreshold: 500000,
      items: [
        {
          id: '2',
          name: 'Золотые серьги с камнями',
          price: 180000,
          quantity: 1,
          image: 'https://images.unsplash.com/photo-1739524553678-d05a2de11588?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmVuZHklMjBhY2Nlc3NvcmllcyUyMGpld2Vscnl8ZW58MXx8fHwxNzU0ODkxMjI2fDA&ixlib=rb-4.1.0&q=80&w=1080'
        },
        {
          id: '3',
          name: 'Серебряное кольцо',
          price: 95000,
          quantity: 2,
          image: 'https://images.unsplash.com/photo-1739524553678-d05a2de11588?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmVuZHklMjBhY2Nlc3NvcmllcyUyMGpld2Vscnl8ZW58MXx8fHwxNzU0ODkxMjI2fDA&ixlib=rb-4.1.0&q=80&w=1080'
        }
      ]
    }
  ]);

  const updateQuantity = (shopId: string, itemId: string, change: number) => {
    setShopCarts(prev => prev.map(shopCart => {
      if (shopCart.shopId === shopId) {
        return {
          ...shopCart,
          items: shopCart.items.map(item => {
            if (item.id === itemId) {
              const newQuantity = Math.max(0, item.quantity + change);
              return { ...item, quantity: newQuantity };
            }
            return item;
          }).filter(item => item.quantity > 0)
        };
      }
      return shopCart;
    }).filter(shopCart => shopCart.items.length > 0));
  };

  const removeItem = (shopId: string, itemId: string) => {
    setShopCarts(prev => prev.map(shopCart => {
      if (shopCart.shopId === shopId) {
        return {
          ...shopCart,
          items: shopCart.items.filter(item => item.id !== itemId)
        };
      }
      return shopCart;
    }).filter(shopCart => shopCart.items.length > 0));
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('ru-RU');
  };

  const calculateShopSubtotal = (shopCart: ShopCart) => {
    return shopCart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const calculateShopDelivery = (shopCart: ShopCart) => {
    const subtotal = calculateShopSubtotal(shopCart);
    return subtotal >= shopCart.freeDeliveryThreshold ? 0 : shopCart.deliveryFee;
  };

  const totalItemsCount = shopCarts.reduce((sum, shopCart) => 
    sum + shopCart.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0
  );

  const grandTotal = shopCarts.reduce((sum, shopCart) => 
    sum + calculateShopSubtotal(shopCart) + calculateShopDelivery(shopCart), 0
  );

  if (shopCarts.length === 0 || totalItemsCount === 0) {
    return (
      <div className="h-full bg-luma-background flex flex-col">
        {/* Header */}
        <div className="flex-shrink-0 flex items-center gap-4 p-6 bg-luma-card shadow-luma-soft">
          <Button variant="ghost" size="icon" onClick={onBack} className="rounded-luma">
            <ArrowLeft className="w-6 h-6 text-luma-primary" />
          </Button>
          <h1 className="text-xl font-bold text-luma-text-dark">Моя корзина</h1>
        </div>

        {/* Empty State */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
          <div className="w-24 h-24 bg-gradient-to-br from-luma-primary/10 to-luma-pink/10 rounded-luma-xl flex items-center justify-center mb-6">
            <ShoppingBag className="w-12 h-12 text-luma-primary" />
          </div>
          <h2 className="text-xl font-bold text-luma-text-dark mb-2">Корзина пуста</h2>
          <p className="text-luma-text-secondary mb-8 max-w-sm">
            Добавьте товары из каталога, чтобы они появились здесь
          </p>
          <Button 
            onClick={onBack}
            className="bg-gradient-to-r from-luma-primary to-luma-pink hover:from-luma-primary/90 hover:to-luma-pink/90 text-white px-8 py-3 rounded-luma shadow-luma"
          >
            Перейти к покупкам
          </Button>
        </div>

        <FloatingBottomNav 
          activeTab={activeTab}
          onTabChange={onTabChange}
        />
      </div>
    );
  }

  return (
    <div className="h-full bg-luma-background flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-4 bg-luma-card shadow-luma-soft pt-[47px] pb-[0px] px-4 pr-[14px] pl-[14px]">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-luma">
          <ArrowLeft className="w-6 h-6 text-luma-primary" />
        </Button>
        <h1 className="text-xl font-bold text-luma-text-dark">Моя корзина</h1>
        <Badge variant="secondary" className="ml-auto bg-luma-primary/10 text-luma-primary">
          {totalItemsCount} {totalItemsCount === 1 ? 'товар' : 'товара'}
        </Badge>
      </div>

      {/* Cart Items - Scrollable - Updated bottom padding for floating CTA and nav */}
      <div className="flex-1 overflow-y-auto space-y-6" style={{ padding: 'var(--section-spacing)', paddingBottom: '200px' }}>
        {shopCarts.map((shopCart) => {
          const shopSubtotal = calculateShopSubtotal(shopCart);
          const shopDelivery = calculateShopDelivery(shopCart);
          const shopTotal = shopSubtotal + shopDelivery;

          return (
            <Card key={shopCart.shopId} className="rounded-luma-lg shadow-luma bg-luma-card overflow-hidden pt-[-5px] pr-[0px] pb-[0px] pl-[0px] mt-[-10px] mr-[0px] mb-[21px] ml-[0px]">
              {/* Shop Header */}
              <div className="bg-gradient-to-r from-luma-primary/5 to-luma-pink/5 p-4 border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-luma-primary/20 to-luma-pink/20 rounded-luma flex items-center justify-center text-lg">
                    {shopCart.shopAvatar}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-luma-text-dark">{shopCart.shopName}</h3>
                      {shopCart.isVerified && (
                        <div className="w-4 h-4 bg-luma-primary rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full" />
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-luma-text-secondary">
                      {shopCart.items.length} {shopCart.items.length === 1 ? 'товар' : 'товара'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-luma-primary">{formatPrice(shopTotal)}</p>
                    <p className="text-xs text-luma-text-secondary">с доставкой</p>
                  </div>
                </div>
              </div>

              {/* Shop Items */}
              <div className="p-4 space-y-4">
                {shopCart.items.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    {/* Product Image */}
                    <div className="w-20 h-20 bg-gray-100 rounded-luma overflow-hidden flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Product Info */}
                    <div className="flex-1 space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold text-luma-text-dark text-sm line-clamp-2 leading-tight">
                            {item.name}
                          </h4>
                          {(item.size || item.color) && (
                            <div className="flex gap-2 mt-1">
                              {item.size && (
                                <span className="text-xs text-luma-text-secondary bg-gray-100 px-2 py-1 rounded">
                                  {item.size}
                                </span>
                              )}
                              {item.color && (
                                <span className="text-xs text-luma-text-secondary bg-gray-100 px-2 py-1 rounded">
                                  {item.color}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(shopCart.shopId, item.id)}
                          className="w-8 h-8 text-luma-coral hover:bg-luma-coral/10 rounded-luma"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        {/* Price */}
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-luma-primary text-sm">
                            {formatPrice(item.price)}
                          </span>
                          {item.originalPrice && (
                            <span className="text-xs text-luma-text-secondary line-through">
                              {formatPrice(item.originalPrice)}
                            </span>
                          )}
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(shopCart.shopId, item.id, -1)}
                            className="w-8 h-8 rounded-luma border-luma-primary/20 hover:bg-luma-primary/5"
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <span className="w-8 text-center font-medium">
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(shopCart.shopId, item.id, 1)}
                            className="w-8 h-8 rounded-luma border-luma-primary/20 hover:bg-luma-primary/5"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Shop Summary */}
              <div className="bg-gray-50 p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-luma-text-secondary">Товары</span>
                  <span className="text-luma-text-dark">{formatPrice(shopSubtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-luma-text-secondary">Доставка</span>
                  <span className={shopDelivery === 0 ? 'text-luma-mint font-medium' : 'text-luma-text-dark'}>
                    {shopDelivery === 0 ? 'Бесплатно' : formatPrice(shopDelivery)}
                  </span>
                </div>
                {shopDelivery > 0 && (
                  <div className="text-xs text-luma-text-secondary">
                    До бесплатной доставки: {formatPrice(shopCart.freeDeliveryThreshold - shopSubtotal)}
                  </div>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Floating CTA above bottom navigation */}
      <StickyActionBar
        layout="oneButton"
        summary="price"
        summaryTitle="Итого"
        summaryValue={formatPrice(grandTotal)}
        primaryLabel="Оформить заказ"
        state={totalItemsCount === 0 ? 'disabled' : 'default'}
        onPrimaryClick={onCheckout}
        variant="floating"
        bottomOffset={112} // 88px nav + 24px gap
      />

      {/* Floating Navigation Bar */}
      <FloatingBottomNav 
        activeTab={activeTab}
        onTabChange={onTabChange}
      />
    </div>
  );
}