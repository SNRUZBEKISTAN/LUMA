import React from 'react';
import { Button } from './ui/button';

interface StickyActionBarProps {
  // Layout configuration
  layout: 'oneButton' | 'twoButtons';
  
  // Summary configuration
  summary?: 'none' | 'price';
  summaryTitle?: string;
  summaryValue?: string;
  
  // Button configuration
  primaryLabel: string;
  secondaryLabel?: string;
  
  // State configuration
  state?: 'default' | 'disabled';
  
  // Position configuration
  variant?: 'default' | 'floating';
  bottomOffset?: number; // Distance from bottom in px (for floating variant)
  
  // Event handlers
  onPrimaryClick: () => void;
  onSecondaryClick?: () => void;
  
  // Additional props
  className?: string;
}

export function StickyActionBar({
  layout,
  summary = 'none',
  summaryTitle,
  summaryValue,
  primaryLabel,
  secondaryLabel,
  state = 'default',
  onPrimaryClick,
  onSecondaryClick,
  className = '',
  variant = 'default',
  bottomOffset = 0
}: StickyActionBarProps) {
  const isDisabled = state === 'disabled';
  const hasSummary = summary !== 'none' && summaryValue;
  
  const handlePrimaryClick = () => {
    if (isDisabled) return;
    
    // Light haptic feedback simulation (in real app would use native haptics)
    console.log('Haptic: light');
    onPrimaryClick();
  };
  
  const handleSecondaryClick = () => {
    if (isDisabled || !onSecondaryClick) return;
    onSecondaryClick();
  };

  const containerStyle = variant === 'floating' 
    ? {
        position: 'fixed' as const,
        bottom: `${bottomOffset}px`,
        left: '16px',
        right: '16px',
        zIndex: 40, // Below modals but above content
        margin: 0,
        padding: 0
      }
    : {};

  const outerContainerStyle = variant === 'floating'
    ? {
        margin: 0,
        padding: 0
      }
    : {};

  const innerContainerStyle = variant === 'floating'
    ? {
        height: 'var(--luma-space-sticky-height)',
        borderRadius: 'var(--luma-space-radius-floating)',
        boxShadow: '0 8px 24px rgba(0,0,0,.08)'
      }
    : {
        height: 'var(--luma-space-sticky-height)',
        boxShadow: '0 8px 24px rgba(0,0,0,.08)'
      };

  return (
    <div 
      className={`${variant === 'floating' ? '' : 'fixed bottom-0 left-0 right-0'} z-50 ${className}`}
      style={containerStyle}
    >
      {/* Safe area padding + outer margins */}
      <div 
        className={variant === 'floating' ? '' : 'px-4 pb-3 safe-area-bottom'}
        style={outerContainerStyle}
      >
        {/* Main container with shadow and styling */}
        <div 
          className={`bg-luma-surface-0 ${variant === 'floating' ? '' : 'rounded-luma-lg'} border border-luma-border-200`}
          style={innerContainerStyle}
        >
          {/* Inner content with proper padding and gap */}
          <div className="flex items-end justify-between px-4 pt-6 pb-1 gap-2" style={{ height: '70px' }}>
            {/* Left Summary Section (Optional) */}
            {hasSummary && (
              <div className="flex-shrink-0">
                {summaryTitle && (
                  <div className="text-luma-text-900 mb-1 luma-type-cap-12">
                    {summaryTitle}
                  </div>
                )}
                <div className="text-luma-text-900 luma-type-price-16">
                  {summaryValue}
                </div>
              </div>
            )}
            
            {/* Right Actions Section */}
            <div className={`flex ${hasSummary ? 'flex-1 justify-end' : 'flex-1'}`}>
              <Button
                onClick={handlePrimaryClick}
                disabled={isDisabled}
                className={`
                  bg-luma-primary-600 hover:bg-luma-primary-500 text-white
                  disabled:bg-luma-primary-600
                  ${isDisabled ? 'opacity-50' : ''}
                `}
                style={{
                  height: '36px',
                  minWidth: '140px',
                  borderRadius: '12px',
                  fontSize: '14px',
                  fontWeight: '700',
                  lineHeight: '20px'
                }}
              >
                {primaryLabel}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Export default for easier imports
export default StickyActionBar;