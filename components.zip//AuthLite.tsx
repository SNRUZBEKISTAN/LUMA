import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { NoAccessModal } from './NoAccessModal';
import { Eye, EyeOff, User, Store } from 'lucide-react';

type UserRole = 'buyer' | 'seller';

interface AuthLiteProps {
  onAuthComplete: (userData: any) => void;
  onRegister: () => void;
  onForgotPassword: () => void;
}

export function AuthLite({ onAuthComplete, onRegister, onForgotPassword }: AuthLiteProps) {
  const [selectedRole, setSelectedRole] = React.useState<UserRole>('buyer');
  const [credentials, setCredentials] = React.useState({
    sellerId: '',
    phoneOrEmail: '',
    password: ''
  });
  const [showPassword, setShowPassword] = React.useState(false);
  const [showNoAccessModal, setShowNoAccessModal] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    // Clear seller ID when switching to buyer
    if (role === 'buyer') {
      setCredentials(prev => ({ ...prev, sellerId: '' }));
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const handleLogin = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock successful login
    const userData = {
      id: 1,
      name: selectedRole === 'buyer' ? 'Покупатель' : 'Продавец',
      email: credentials.phoneOrEmail,
      role: selectedRole,
      sellerId: selectedRole === 'seller' ? credentials.sellerId : undefined
    };

    setIsLoading(false);
    onAuthComplete(userData);
  };

  const handleSocialLogin = (provider: 'apple' | 'google') => {
    console.log(`Login with ${provider}`);
    // Mock social login
    const userData = {
      id: 1,
      name: selectedRole === 'buyer' ? 'Покупатель' : 'Продавец',
      email: `user@${provider}.com`,
      role: selectedRole
    };
    onAuthComplete(userData);
  };

  const isFormValid = () => {
    const baseValid = credentials.phoneOrEmail.trim() && credentials.password.trim();
    if (selectedRole === 'seller') {
      return baseValid && credentials.sellerId.trim();
    }
    return baseValid;
  };

  return (
    <div className="h-full flex flex-col bg-luma-bg-0">
      <div className="flex-1 flex flex-col justify-center px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-luma-primary-600 mb-2">LUMA</h1>
          <p className="text-base text-luma-text-600">Добро пожаловать в LUMA</p>
        </div>

        {/* Role Picker */}
        <div className="mb-8">
          <div className="flex gap-4">
            <button
              onClick={() => handleRoleSelect('buyer')}
              className={`flex-1 flex flex-col items-center gap-3 p-6 rounded-luma border-2 transition-all ${
                selectedRole === 'buyer'
                  ? 'bg-luma-primary-600/10 border-luma-primary-600'
                  : 'bg-luma-surface-0 border-luma-border-200 hover:border-luma-primary-500'
              }`}
            >
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                selectedRole === 'buyer' ? 'bg-luma-primary-600' : 'bg-luma-primary-200'
              }`}>
                <User className={`w-6 h-6 ${
                  selectedRole === 'buyer' ? 'text-white' : 'text-luma-primary-600'
                }`} />
              </div>
              <span className={`font-medium ${
                selectedRole === 'buyer' ? 'text-luma-primary-600' : 'text-luma-text-900'
              }`}>
                Покупатель
              </span>
            </button>

            <button
              onClick={() => handleRoleSelect('seller')}
              className={`flex-1 flex flex-col items-center gap-3 p-6 rounded-luma border-2 transition-all ${
                selectedRole === 'seller'
                  ? 'bg-luma-primary-600/10 border-luma-primary-600'
                  : 'bg-luma-surface-0 border-luma-border-200 hover:border-luma-primary-500'
              }`}
            >
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                selectedRole === 'seller' ? 'bg-luma-primary-600' : 'bg-luma-primary-200'
              }`}>
                <Store className={`w-6 h-6 ${
                  selectedRole === 'seller' ? 'text-white' : 'text-luma-primary-600'
                }`} />
              </div>
              <span className={`font-medium ${
                selectedRole === 'seller' ? 'text-luma-primary-600' : 'text-luma-text-900'
              }`}>
                Продавец
              </span>
            </button>
          </div>
        </div>

        {/* Login Form */}
        <Card className="p-6 bg-luma-surface-0 rounded-luma shadow-luma-soft">
          <div className="space-y-4">
            {/* Seller ID Field (only for sellers) */}
            {selectedRole === 'seller' && (
              <div>
                <Input
                  type="text"
                  placeholder="Например: S-123456"
                  value={credentials.sellerId}
                  onChange={(e) => handleInputChange('sellerId', e.target.value)}
                  className="bg-luma-surface-0 border-luma-border-200 focus:border-luma-primary-600 rounded-luma"
                />
              </div>
            )}

            {/* Phone or Email Field */}
            <div>
              <Input
                type="text"
                placeholder="+998 __ ___ __ __  или  name@mail.com"
                value={credentials.phoneOrEmail}
                onChange={(e) => handleInputChange('phoneOrEmail', e.target.value)}
                className="bg-luma-surface-0 border-luma-border-200 focus:border-luma-primary-600 rounded-luma"
              />
            </div>

            {/* Password Field */}
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••"
                value={credentials.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                className="bg-luma-surface-0 border-luma-border-200 focus:border-luma-primary-600 rounded-luma pr-12"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-luma-text-600 hover:text-luma-primary-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {/* Social Login */}
            <div className="flex gap-3 justify-center mt-6">
              <button
                onClick={() => handleSocialLogin('apple')}
                className="w-12 h-12 bg-luma-surface-0 border border-luma-border-200 rounded-xl flex items-center justify-center hover:bg-luma-primary-200 transition-colors"
              >
                <div className="w-6 h-6 bg-luma-text-900 rounded-sm flex items-center justify-center">
                  <span className="text-white text-xs font-bold">🍎</span>
                </div>
              </button>
              <button
                onClick={() => handleSocialLogin('google')}
                className="w-12 h-12 bg-luma-surface-0 border border-luma-border-200 rounded-xl flex items-center justify-center hover:bg-luma-primary-200 transition-colors"
              >
                <span className="text-lg font-bold text-luma-primary-600">G</span>
              </button>
            </div>

            {/* Login Button */}
            <Button
              onClick={handleLogin}
              disabled={!isFormValid() || isLoading}
              className="w-full bg-luma-primary-600 hover:bg-luma-primary-500 text-white rounded-luma h-12 text-base font-medium mt-6"
            >
              {isLoading ? 'Входим...' : 'Войти'}
            </Button>

            {/* Links Row */}
            <div className="flex justify-between items-center pt-4">
              <button
                onClick={onForgotPassword}
                className="text-xs text-luma-text-600 hover:text-luma-primary-600 transition-colors"
              >
                Забыли пароль?
              </button>
              <button
                onClick={() => setShowNoAccessModal(true)}
                className="text-xs text-luma-text-600 hover:text-luma-primary-600 transition-colors"
              >
                Нет доступа к телефону/паролю
              </button>
            </div>
          </div>
        </Card>

        {/* Register Button */}
        <div className="text-center mt-8">
          <button
            onClick={onRegister}
            className="inline-flex items-center gap-2 text-luma-primary-600 hover:text-luma-primary-500 font-medium transition-colors"
          >
            <span className="text-lg">➕</span>
            Создать аккаунт
          </button>
        </div>
      </div>

      {/* No Access Modal */}
      <NoAccessModal
        isOpen={showNoAccessModal}
        onClose={() => setShowNoAccessModal(false)}
      />
    </div>
  );
}