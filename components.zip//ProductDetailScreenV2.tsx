import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from './ui/sheet';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { StoreButton } from './StoreButton';
import { StickyActionBar } from './StickyActionBar';
import { FloatingBottomNav } from './FloatingBottomNav';
import { ProductCardV3 } from './ProductCardV3';
import { ShareSheetModal, useShareSheet } from './ShareSheetModal';
import { ARFloatingButton } from './ARFloatingButton';
import { ARNotReadyModal } from './ARNotReadyModal';
import { ARComingSoonBadge } from './ARComingSoonBadge';
import { SizePicker } from './SizePicker';
import { 
  ArrowLeft, 
  Share, 
  Heart, 
  Star, 
  Check, 
  ChevronRight,
  ChevronDown,
  Play,
  MessageCircle,
  UserPlus
} from 'lucide-react';

interface ProductDetailScreenV2Props {
  onBack: () => void;
  onStoreClick: (storeId: string) => void;
  onAddToCart: (productId: string, options: any) => void;
  onBuyNow: (productId: string, options: any) => void;
  onShare: () => void;
  onWishlistToggle: (productId: string) => void;
  onChatWithStore: (storeId: string) => void;
  onFollowStore: (storeId: string) => void;
}

interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail?: string;
}

interface Review {
  id: string;
  userName: string;
  userAvatar: string;
  rating: number;
  date: string;
  text: string;
  images?: string[];
}

interface RelatedProduct {
  id: string;
  name: string;
  image: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  rating: number;
  shop: {
    id: string;
    name: string;
    avatar: string;
  };
}

const SizePickerSheet = ({ 
  isOpen, 
  onClose, 
  selectedSize, 
  onSizeSelect, 
  sizes 
}: {
  isOpen: boolean;
  onClose: () => void;
  selectedSize: string;
  onSizeSelect: (sizeId: string, available: boolean) => void;
  sizes: Array<{ id: string; label: string; available: boolean }>;
}) => {
  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="bottom" className="h-[45vh] bg-luma-surface-0 rounded-t-luma-lg">
        <SheetHeader className="pb-6">
          <SheetTitle className="text-center text-luma-text-900">Размер</SheetTitle>
          <SheetDescription className="text-center text-luma-text-600 text-sm">
            Выберите подходящий размер для данного товара
          </SheetDescription>
        </SheetHeader>
        
        <div className="flex-1 overflow-hidden">
          {/* iOS-style wheel picker - reduced height with 5 visible rows */}
          <div className="relative h-56 overflow-hidden">
            <div className="absolute inset-x-0 top-1/2 h-11 -translate-y-1/2 bg-luma-primary-200/20 rounded-lg border-2 border-luma-primary-200"></div>
            
            <div className="h-full overflow-y-auto scrollbar-hide snap-y snap-mandatory" style={{ 
              maskImage: 'linear-gradient(to bottom, transparent, black 20%, black 80%, transparent)',
              WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 20%, black 80%, transparent)'
            }}>
              <div className="py-24">
                {sizes.map((size) => (
                  <button
                    key={size.id}
                    onClick={() => onSizeSelect(size.id, size.available)}
                    disabled={!size.available}
                    className={`w-full h-11 snap-center flex items-center justify-center transition-all ${
                      selectedSize === size.id
                        ? 'text-luma-text-900 font-bold text-lg'
                        : size.available
                          ? 'text-luma-text-600 text-base'
                          : 'text-luma-text-600/40 text-base'
                    }`}
                  >
                    <span className="flex items-center justify-between w-full max-w-xs">
                      <span>{size.label}</span>
                      {!size.available && <span className="text-base">🚫</span>}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-luma-border-200">
          <button 
            className="w-full text-luma-primary-600 font-medium mb-4"
            onClick={() => console.log('Size guide')}
          >
            Таблица размеров
          </button>
          <Button
            onClick={onClose}
            className="w-full bg-luma-primary-600 hover:bg-luma-primary-500 text-white rounded-luma"
          >
            Готово
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export function ProductDetailScreenV2({
  onBack,
  onStoreClick,
  onAddToCart,
  onBuyNow,
  onShare,
  onWishlistToggle,
  onChatWithStore,
  onFollowStore
}: ProductDetailScreenV2Props) {
  const [currentMediaIndex, setCurrentMediaIndex] = React.useState(0);
  const [selectedSize, setSelectedSize] = React.useState<string>('');
  const [selectedColor, setSelectedColor] = React.useState<string>('black');
  const [isWishlisted, setIsWishlisted] = React.useState(false);
  const [showSizePicker, setShowSizePicker] = React.useState(false);
  const [isVideoPlaying, setIsVideoPlaying] = React.useState(false);
  const [isFollowing, setIsFollowing] = React.useState(false);
  const [showARModal, setShowARModal] = React.useState(false);

  // Share functionality
  const { shareState, closeShare, share } = useShareSheet();

  // Mock product data
  const product = {
    id: 'prod-001',
    name: 'Платье из вискозы с поясом',
    price: 280000,
    originalPrice: 350000,
    discount: 30,
    rating: 4.8,
    reviewCount: 1245,
    likes: 320,
    orders: 2140,
    description: 'Платье из лёгкой вискозы с поясом. Мягкая посадка, длина миди. Подходит для повседневных и вечерних образов. Рекомендуем ручную стирку.',
    shop: {
      id: 'shop-fashion',
      name: 'Fashion Co',
      avatar: '👗'
    },
    attributes: {
      'Тип': 'Платье',
      'Цвета': 'Чёрный, Бежевый, Розовый',
      'Материал': 'Вискоза 70%, ПЭ 30%',
      'Размерная сетка': 'EU',
      'Категория': 'Женская одежда',
      'Страна производства': 'Турция',
      'Артикул': 'LUM-5842'
    }
  };

  const mediaItems: MediaItem[] = [
    {
      id: '1',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=500&fit=crop'
    },
    {
      id: '2',
      type: 'video',
      url: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=300&fit=crop',
      thumbnail: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=300&fit=crop'
    },
    {
      id: '3',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1583496661160-fb5886a13d35?w=400&h=500&fit=crop'
    }
  ];

  const sizes = [
    { id: 'xxs', label: 'XXS', available: false },
    { id: 'xs', label: 'XS', available: true },
    { id: 's', label: 'S', available: true },
    { id: 'm', label: 'M', available: true },
    { id: 'l', label: 'L', available: false },
    { id: 'xl', label: 'XL', available: true }
  ];

  const colors = [
    { id: 'black', label: 'Чёрный', hex: '#000000', available: true },
    { id: 'beige', label: 'Бежевый', hex: '#F5F5DC', available: true },
    { id: 'pink', label: 'Розовый', hex: '#FFC0CB', available: false }
  ];

  const reviews: Review[] = [
    {
      id: '1',
      userName: 'Анна К.',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face',
      rating: 5,
      date: '15 дек',
      text: 'Отличное платье! Качество материала превосходное, очень удобное и стильное. Рекомендую всем!',
      images: ['https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=80&h=80&fit=crop']
    },
    {
      id: '2',
      userName: 'Мария Д.',
      userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face',
      rating: 4,
      date: '12 дек',
      text: 'Красивое платье, но размер немного маловат. Советую брать на размер больше для комфорта.'
    },
    {
      id: '3',
      userName: 'Елена С.',
      userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=40&h=40&fit=crop&crop=face',
      rating: 5,
      date: '10 дек',
      text: 'Превосходное качество! Платье сидит идеально, материал приятный к телу.'
    }
  ];

  const otherFromSeller: RelatedProduct[] = [
    {
      id: '1',
      name: 'Блузка шёлковая',
      image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=160&h=200&fit=crop',
      price: 125000,
      rating: 4.6,
      shop: product.shop
    },
    {
      id: '2',
      name: 'Юбка плиссе',
      image: 'https://images.unsplash.com/photo-1583496661160-fb5886a13d35?w=160&h=200&fit=crop',
      price: 95000,
      originalPrice: 140000,
      discount: 32,
      rating: 4.9,
      shop: product.shop
    }
  ];

  const similarProducts: RelatedProduct[] = [
    {
      id: '1',
      name: 'Платье летнее макси',
      image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=180&h=240&fit=crop',
      price: 180000,
      rating: 4.7,
      shop: { id: 'chic', name: 'Chic', avatar: '💅' }
    },
    {
      id: '2',
      name: 'Платье коктейльное',
      image: 'https://images.unsplash.com/photo-1566479179817-c0e393e3000a?w=180&h=240&fit=crop',
      price: 290000,
      originalPrice: 420000,
      discount: 31,
      rating: 4.9,
      shop: { id: 'nova', name: 'Nova', avatar: '✨' }
    }
  ];

  const popularProducts: RelatedProduct[] = [
    {
      id: '1',
      name: 'Блузка классическая',
      image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=180&h=240&fit=crop',
      price: 89000,
      rating: 4.5,
      shop: { id: 'style', name: 'Style', avatar: '👔' }
    },
    {
      id: '2',
      name: 'Юбка мини',
      image: 'https://images.unsplash.com/photo-1583496661160-fb5886a13d35?w=180&h=240&fit=crop',
      price: 65000,
      originalPrice: 85000,
      discount: 24,
      rating: 4.8,
      shop: { id: 'trend', name: 'Trend', avatar: '🌟' }
    },
    {
      id: '3',
      name: 'Кардиган вязаный',
      image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=180&h=240&fit=crop',
      price: 120000,
      rating: 4.6,
      shop: { id: 'cozy', name: 'Cozy', avatar: '🧶' }
    },
    {
      id: '4',
      name: 'Топ кружевной',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=180&h=240&fit=crop',
      price: 75000,
      originalPrice: 95000,
      discount: 21,
      rating: 4.7,
      shop: { id: 'lace', name: 'Lace', avatar: '🌸' }
    },
    {
      id: '5',
      name: 'Брюки зауженные',
      image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=180&h=240&fit=crop',
      price: 110000,
      rating: 4.4,
      shop: { id: 'urban', name: 'Urban', avatar: '🏙️' }
    },
    {
      id: '6',
      name: 'Жакет льняной',
      image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=180&h=240&fit=crop',
      price: 140000,
      originalPrice: 180000,
      discount: 22,
      rating: 4.9,
      shop: { id: 'linen', name: 'Linen', avatar: '🌾' }
    }
  ];

  const formatPrice = (price: number) => {
    return price.toLocaleString('ru-RU');
  };

  const handleSizeSelect = (sizeId: string, available: boolean) => {
    if (!available) {
      alert('Размер недоступен');
      return;
    }
    setSelectedSize(sizeId);
  };

  const handleSizePickerSelect = (selectedLabel: string) => {
    // Найдем размер по label и установим его id
    const sizeItem = sizes.find(size => size.label === selectedLabel);
    if (sizeItem && sizeItem.available) {
      setSelectedSize(sizeItem.id);
    }
  };

  // Безопасная функция для получения label размера
  const getSizeLabel = (sizeId: string) => {
    const size = sizes.find(s => s.id === sizeId);
    const result = size ? size.label : '';
    // Убедимся что возвращаем строку, а не объект
    return typeof result === 'string' ? result : String(result);
  };

  const handleColorSelect = (colorId: string, available: boolean) => {
    if (!available) {
      alert('Нет в наличии. Уведомить о поступлении?');
      return;
    }
    setSelectedColor(colorId);
  };

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Выберите размер');
      return;
    }
    const options = { size: selectedSize, color: selectedColor };
    onAddToCart(product.id, options);
    alert('Добавлено в корзину');
  };

  const handleBuyNow = () => {
    if (!selectedSize) {
      alert('Выберите размер');
      return;
    }
    const options = { size: selectedSize, color: selectedColor };
    onBuyNow(product.id, options);
  };

  const handleWishlistToggle = () => {
    setIsWishlisted(!isWishlisted);
    onWishlistToggle(product.id);
  };

  const handleFollowStore = () => {
    setIsFollowing(!isFollowing);
    onFollowStore(product.shop.id);
  };

  const handleVideoPlay = () => {
    setIsVideoPlaying(true);
    // In real app, this would start video playback
  };

  const handleShare = () => {
    const productUrl = `${window.location.origin}/product/${product.id}`;
    share(productUrl, product.name);
  };

  const handleARTryOn = () => {
    // Check if AR is supported or available
    const isARSupported = false; // For now, AR is not ready
    
    if (isARSupported) {
      // Launch AR camera
      console.log('Launching AR camera...');
    } else {
      setShowARModal(true);
    }
  };

  return (
    <div className="h-full flex flex-col bg-luma-bg-0">
      {/* iOS Header - Product name as title */}
      <div className="flex-shrink-0 bg-luma-surface-0 px-4 pt-[47px] pb-[14px] shadow-luma-soft pr-[14px] pl-[14px]">
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-luma-primary-200 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-luma-text-900" />
          </button>
          
          <h1 className="text-17 font-semibold text-luma-text-900 line-clamp-1 flex-1 text-center mx-4"
              style={{ fontSize: '17px', lineHeight: '22px' }}>
            {product.name}
          </h1>

          <button
            onClick={handleShare}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-luma-primary-200 transition-colors"
          >
            <Share className="w-5 h-5 text-luma-text-900" />
          </button>
        </div>
      </div>

      {/* Scrollable Content - Updated bottom padding for StickyActionBar */}
      <div className="flex-1 overflow-y-auto pb-32">
        {/* 1. Media Carousel - Content padding L/R = 16px */}
        <div className="px-4 mt-[0px] mr-[0px] mb-[-10px] ml-[0px]">
          <div className="relative aspect-[4/5] bg-luma-surface-0 rounded-0">
            <ImageWithFallback
              src={mediaItems[currentMediaIndex].url}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            
            {/* Video Play Button & Badge */}
            {mediaItems[currentMediaIndex].type === 'video' && !isVideoPlaying && (
              <>
                <button
                  onClick={handleVideoPlay}
                  className="absolute inset-0 flex items-center justify-center bg-black/20"
                >
                  <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center shadow-lg">
                    <Play className="w-8 h-8 text-luma-text-900 ml-1" />
                  </div>
                </button>
                <div className="absolute top-4 right-4">
                  <Badge className="bg-luma-text-900/80 text-white px-3 py-1 rounded-lg">
                    Видеообзор
                  </Badge>
                </div>
              </>
            )}

            {/* AR Floating Button */}
            <ARFloatingButton onClick={handleARTryOn} />

            {/* Media Dots */}
            {mediaItems.length > 1 && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                {mediaItems.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentMediaIndex(index)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentMediaIndex ? 'bg-luma-primary-600' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
          
          {/* AR Coming Soon Badge */}
          <ARComingSoonBadge />
        </div>

        <div className="px-4 py-6 space-y-6 pt-[0px] pr-[14px] pb-[21px] pl-[14px]">
          {/* 2. Store Row - Using StoreButton component with proper navigation */}
          <div className="flex items-center justify-between">
            <StoreButton
              storeId={product.shop.id}
              storeName={product.shop.name}
              storeAvatar={product.shop.avatar}
              avatarSize={32}
              nameSize="base"
              onStoreClick={onStoreClick}
              className="p-2 flex-1 justify-start"
            />
            
            <button
              onClick={handleWishlistToggle}
              className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-luma-primary-200/50 transition-colors min-h-[44px] min-w-[44px]"
              aria-label={isWishlisted ? 'Убрать из избранного' : 'Добавить в избранное'}
            >
              <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-luma-text-600'}`} />
              <span className="text-xs uppercase tracking-wide text-luma-text-600 font-medium">
                {product.likes}
              </span>
            </button>
          </div>

          {/* 3. Title + Meta - Moved under store row with larger title */}
          <div>
            <h2 className="text-lg font-bold text-luma-text-900 mb-1 line-clamp-2" style={{ fontSize: '18px', lineHeight: '24px' }}>
              {product.name}
            </h2>
            
            <p className="text-xs text-gray-500 mb-3">Артикул: {product.id}</p>
            
            <div className="flex items-center gap-4 text-xs uppercase tracking-wide text-luma-text-600">
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{product.rating}</span>
                <span>({product.reviewCount.toLocaleString()})</span>
              </div>
              <span>•</span>
              <div className="flex items-center gap-1">
                <Heart className="w-3 h-3" />
                <span>{product.likes}</span>
              </div>
              <span>•</span>
              <div>
                <span>Заказов: {product.orders.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 4. Edge-to-Edge Price Band - Updated font sizes */}
        <div className="relative -mx-4 bg-luma-primary-200/90 shadow-luma-soft mx-[10px] my-[0px] rounded-[10px]">
          <div className="px-4 py-4 rounded-[10px] px-[5px] py-[14px] mx-[10px] mx-[5px] my-[0px]">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-luma-text-900" style={{ fontSize: '21px', lineHeight: '28px' }}>
                  Сейчас: {formatPrice(product.price)}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-luma-text-600 line-through" style={{ fontSize: '14px', lineHeight: '18px', fontWeight: '400' }}>
                  {formatPrice(product.originalPrice)}
                </span>
                <Badge className="bg-luma-danger-600 text-white rounded-lg font-bold px-3 py-1 min-w-[44px] h-[28px] flex items-center justify-center" 
                       style={{ fontSize: '14px', lineHeight: '18px' }}>
                  −{product.discount}%
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 py-6 space-y-6">
          {/* 5. Options */}
          <div className="space-y-6">
            {/* Colors */}
            <div>
              <h3 className="font-semibold text-luma-text-900 mb-3">Цвет</h3>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide">
                {colors.map((color) => (
                  <button
                    key={color.id}
                    onClick={() => handleColorSelect(color.id, color.available)}
                    className={`relative w-7 h-7 rounded-full border-2 transition-all flex-shrink-0 ${
                      selectedColor === color.id
                        ? 'border-luma-primary-600'
                        : 'border-luma-border-200'
                    } ${!color.available ? 'opacity-50' : ''}`}
                    style={{ backgroundColor: color.hex }}
                    title={color.label}
                  >
                    {selectedColor === color.id && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Check className="w-4 h-4 text-white drop-shadow-lg" />
                      </div>
                    )}
                    {!color.available && (
                      <div className="absolute inset-0 bg-red-500/20 rounded-full">
                        <div className="w-full h-0.5 bg-red-500 transform rotate-45 translate-y-3" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Picker */}
            <div>
              <h3 className="font-semibold text-luma-text-900 mb-3">Размер</h3>
              <button
                onClick={() => setShowSizePicker(true)}
                className="flex items-center justify-between w-full p-3 border border-luma-border-200 rounded-luma hover:border-luma-primary-600 transition-colors"
              >
                <span className={selectedSize ? 'text-luma-text-900 font-medium' : 'text-luma-text-600'}>
                  {selectedSize ? getSizeLabel(selectedSize) || 'Размер не найден' : 'Выбрать размер'}
                </span>
                <ChevronDown className="w-5 h-5 text-luma-text-600" />
              </button>
            </div>
          </div>

          {/* 6. Short Description */}
          <div>
            <p className="text-luma-text-600 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* 7. Attributes */}
          <div>
            <h3 className="font-semibold text-luma-text-900 mb-4">Характеристики</h3>
            <div className="bg-luma-surface-0 rounded-luma p-4 space-y-3">
              {Object.entries(product.attributes).map(([key, value]) => (
                <div key={key} className="flex justify-between items-start border-b border-luma-border-200 pb-2 last:border-b-0 last:pb-0">
                  <dt className="text-sm text-luma-text-600 w-1/3">{key}</dt>
                  <dd className="text-sm font-medium text-luma-text-900 w-2/3 text-right">{value}</dd>
                </div>
              ))}
            </div>
          </div>

          {/* 8. Reviews - Horizontal Slider */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-luma-text-900">
                Отзывы {product.rating} ({product.reviewCount.toLocaleString()})
              </h3>
              <button className="flex items-center gap-1 text-luma-primary-600 font-medium">
                <span>Смотреть всё</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex gap-4 overflow-x-auto scrollbar-hide -mx-4 px-4">
              {reviews.map((review) => (
                <div key={review.id} className="bg-luma-surface-0 p-4 rounded-luma flex-shrink-0 w-80 shadow-luma-soft">
                  <div className="flex items-center gap-3 mb-3">
                    <ImageWithFallback
                      src={review.userAvatar}
                      alt={review.userName}
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-luma-text-900">{review.userName}</span>
                        <span className="text-sm text-luma-text-600">{review.date}</span>
                      </div>
                      <div className="flex items-center mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < review.rating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-luma-border-200'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-luma-text-900 text-sm line-clamp-3 mb-3">{review.text}</p>
                  
                  {review.images && (
                    <div className="flex gap-2">
                      {review.images.map((image, index) => (
                        <ImageWithFallback
                          key={index}
                          src={image}
                          alt="Review"
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 9. Other from Seller */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-luma-text-900">Другие товары магазина</h3>
              <button 
                onClick={() => onStoreClick(product.shop.id)}
                className="flex items-center gap-1 text-luma-primary-600 font-medium"
              >
                <span>Смотреть всё</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            
            <div className="overflow-x-auto overflow-y-hidden scrollbar-hide -mx-4" 
                 style={{ 
                   scrollSnapType: 'x mandatory',
                   paddingLeft: '16px',
                   paddingRight: '16px'
                 }}>
              <div 
                className="flex gap-3" 
                style={{ 
                  width: 'max-content'
                }}
              >
                {otherFromSeller.map((product) => (
                  <div 
                    key={product.id}
                    className="flex-shrink-0"
                    style={{ 
                      scrollSnapAlign: 'start',
                      width: '112px'
                    }}
                  >
                    <ProductCardV3
                      id={product.id}
                      title={product.name}
                      image={product.image}
                      price={product.price}
                      originalPrice={product.originalPrice}
                      discount={product.discount ? `-${product.discount}%` : undefined}
                      rating={product.rating}
                      size="xs"
                      context="store"
                      hasPill={!!product.discount}
                      hasRating={true}
                      likes={Math.floor(Math.random() * 100) + 20}
                      orders={Math.floor(Math.random() * 500) + 100}
                      onProductClick={(id) => console.log('Product clicked:', id)}
                      onLikeToggle={(id) => console.log('Like toggled:', id)}
                      onQuickAdd={(id) => console.log('Quick add:', id)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 10. Similar Products */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-luma-text-900">Похожие товары</h3>
              <button className="flex items-center gap-1 text-luma-primary-600 font-medium">
                <span>Смотреть всё</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              {similarProducts.map((product) => (
                <ProductCardV3
                  key={product.id}
                  id={product.id}
                  title={product.name}
                  image={product.image}
                  price={product.price}
                  originalPrice={product.originalPrice}
                  discount={product.discount ? `-${product.discount}%` : undefined}
                  storeName={product.shop.name}
                  storeAvatar={product.shop.avatar}
                  rating={product.rating}
                  size="xs"
                  context="global"
                  hasPill={!!product.discount}
                  hasRating={true}
                  likes={Math.floor(Math.random() * 100) + 20}
                  orders={Math.floor(Math.random() * 500) + 100}
                  onProductClick={(id) => console.log('Product clicked:', id)}
                  onLikeToggle={(id) => console.log('Like toggled:', id)}
                  onQuickAdd={(id) => console.log('Quick add:', id)}
                  onStoreClick={onStoreClick}
                />
              ))}
            </div>
          </div>

          {/* 11. Popular Products - Horizontal scroll with 3 columns visible */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-luma-text-900">Популярные товары</h3>
              <button className="flex items-center gap-1 text-luma-primary-600 font-medium">
                <span>Смотреть всё</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            
            <div className="overflow-x-auto overflow-y-hidden scrollbar-hide -mx-4" 
                 style={{ 
                   scrollSnapType: 'x mandatory',
                   paddingLeft: '16px',
                   paddingRight: '16px'
                 }}>
              <div 
                className="flex gap-3" 
                style={{ 
                  width: 'max-content'
                }}
              >
                {popularProducts.map((product) => (
                  <div 
                    key={product.id}
                    className="flex-shrink-0"
                    style={{ 
                      scrollSnapAlign: 'start',
                      width: '112px'
                    }}
                  >
                    <ProductCardV3
                      id={product.id}
                      title={product.name}
                      image={product.image}
                      price={product.price}
                      originalPrice={product.originalPrice}
                      discount={product.discount ? `-${product.discount}%` : undefined}
                      storeName={product.shop.name}
                      storeAvatar={product.shop.avatar}
                      rating={product.rating}
                      size="xs"
                      context="global"
                      hasPill={!!product.discount}
                      hasRating={true}
                      likes={Math.floor(Math.random() * 100) + 20}
                      orders={Math.floor(Math.random() * 500) + 100}
                      onProductClick={(id) => console.log('Product clicked:', id)}
                      onLikeToggle={(id) => console.log('Like toggled:', id)}
                      onQuickAdd={(id) => console.log('Quick add:', id)}
                      onStoreClick={onStoreClick}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <StickyActionBar
        layout="twoButtons"
        summary="price"
        summaryTitle="Итого"
        summaryValue={formatPrice(product.price)}
        primaryLabel="Купить сейчас"
        secondaryLabel="В корзину"
        state={!selectedSize ? 'disabled' : 'default'}
        onPrimaryClick={handleBuyNow}
        onSecondaryClick={handleAddToCart}
      />

      {/* Size Picker */}
      <SizePicker
        isOpen={showSizePicker}
        onClose={() => setShowSizePicker(false)}
        selectedSize={getSizeLabel(selectedSize)}
        onSizeSelect={handleSizePickerSelect}
        sizes={sizes.filter(size => size.available).map(size => String(size.label))}
      />

      {/* Share Sheet Modal */}
      <ShareSheetModal
        isOpen={shareState.isOpen}
        onClose={closeShare}
        url={shareState.url || ''}
        title={shareState.title || ''}
      />

      {/* AR Not Ready Modal */}
      <ARNotReadyModal
        isOpen={showARModal}
        onClose={() => setShowARModal(false)}
      />
    </div>
  );
}