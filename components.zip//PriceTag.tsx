import React from 'react';

export interface PriceTagProps {
  price: number;
  originalPrice?: number;
  currency?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'compact' | 'prominent';
}

export function PriceTag({
  price,
  originalPrice,
  currency = 'сум',
  size = 'md',
  variant = 'default'
}: PriceTagProps) {
  const sizeClasses = {
    sm: 'text-lg',
    md: 'text-lg', 
    lg: 'text-xl'
  };

  const originalPriceSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  if (variant === 'compact') {
    return (
      <div className="flex items-end gap-1 flex-wrap">
        {originalPrice && (
          <div className="flex flex-col flex-shrink-0">
            <span className="text-xs text-gray-500 leading-tight">было:</span>
            <div className="flex items-center gap-0.5">
              <span className={`line-through text-gray-400 ${originalPriceSizeClasses[size]}`}>
                {originalPrice.toLocaleString()}
              </span>
              <span className="text-xs text-gray-400">{currency}</span>
            </div>
          </div>
        )}
        <div className="flex items-center gap-0.5 flex-shrink-0">
          <span className={`font-semibold text-purple-600 ${sizeClasses[size]}`}>
            {price.toLocaleString()}
          </span>
          <span className="text-sm text-purple-500">{currency}</span>
        </div>
      </div>
    );
  }

  if (variant === 'prominent') {
    return (
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-3 border border-purple-100">
        {originalPrice && (
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-gray-500">Было:</span>
            <span className="text-sm line-through text-gray-400">
              {originalPrice.toLocaleString()} {currency}
            </span>
          </div>
        )}
        <div className="flex items-baseline gap-1">
          <span className={`font-bold text-purple-600 ${sizeClasses[size]}`}>
            {price.toLocaleString()}
          </span>
          <span className="text-sm text-purple-500">{currency}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      {originalPrice && (
        <span className={`line-through text-gray-400 ${originalPriceSizeClasses[size]}`}>
          {originalPrice.toLocaleString()} {currency}
        </span>
      )}
      <div className="bg-[#F6F3FF] rounded-md py-2 px-3 inline-block">
        <span className={`font-semibold text-purple-600 ${sizeClasses[size]}`}>
          {price.toLocaleString()} {currency}
        </span>
      </div>
    </div>
  );
}

export default PriceTag;