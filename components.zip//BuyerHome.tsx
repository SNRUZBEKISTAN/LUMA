import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { FloatingBottomNav } from './FloatingBottomNav';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ProductCardV3 } from './ProductCardV3';
import { ProductCardSmall } from './ProductCardSmall';
import { ProductCardMedium } from './ProductCardMedium';
import { ProductCardModern } from './ProductCardModern';
import { ProductCardCompact } from './ProductCardCompact';
import { ProductCarousel } from './ProductCarousel';
import { StoriesSection } from './StoriesSection';
import { QuickTile } from './QuickTile';
import { StoryViewer, StoreStories } from './story/StoryViewer';
import { StoriesShops } from './StoriesShops';
import { MagicCallout } from './MagicCallout';
import { StorePromoSlider } from './StorePromoSlider';
import { PhotoSearchModal } from './PhotoSearchModal';
import { 
  Bell, 
  Search, 
  Star, 
  ShoppingCart,
  Heart,
  ChevronRight,
  Camera,
  Sparkles,
  Zap,
  Gift,
  Percent,
  TrendingUp
} from 'lucide-react';

interface BuyerHomeProps {
  onProductClick: (productId: string) => void;
  onCartClick: () => void;
  onTabChange: (tab: string) => void;
  activeTab: string;
  showBackButton?: boolean;
  onBack?: () => void;
  onSearchClick?: () => void;
  onNotificationsClick?: () => void;
  onAILookClick?: () => void;
  onFavoritesClick?: () => void;
}

export function BuyerHome({ 
  onProductClick, 
  onCartClick, 
  onTabChange, 
  activeTab,
  showBackButton = false,
  onBack,
  onSearchClick,
  onNotificationsClick,
  onAILookClick,
  onFavoritesClick
}: BuyerHomeProps) {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [storyViewer, setStoryViewer] = React.useState({
    isOpen: false,
    storeIndex: 0,
    itemIndex: 0
  });
  const [isPhotoSearchOpen, setIsPhotoSearchOpen] = React.useState(false);

  // Enhanced stories data with products
  const storiesData: StoreStories[] = [
    {
      storeId: 'urban',
      storeName: 'Urban',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      items: [
        {
          id: 'urban-1',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '1',
            name: 'Стильная куртка премиум качества',
            price: '280 000',
            currency: 'сум',
            availableSizes: ['S', 'M', 'L', 'XL'],
            likes: 1248,
            orders: 89
          }
        },
        {
          id: 'urban-2',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '7',
            name: 'Деловой костюм премиум',
            price: '450 000',
            currency: 'сум',
            availableSizes: ['48', '50', '52', '54'],
            likes: 892,
            orders: 45
          }
        }
      ]
    },
    {
      storeId: 'nova',
      storeName: 'Nova',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
      items: [
        {
          id: 'nova-1',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '3',
            name: 'Спортивные кроссовки Nike',
            price: '315 000',
            currency: 'сум',
            availableSizes: ['39', '40', '41', '42', '43'],
            likes: 2156,
            orders: 178
          }
        }
      ]
    },
    {
      storeId: 'chic',
      storeName: 'Chic',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612e2d3?w=40&h=40&fit=crop&crop=face',
      items: [
        {
          id: 'chic-1',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1566479179817-0dcc6b11d8b5?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '5',
            name: 'Вечернее платье эксклюзив',
            price: '650 000',
            currency: 'сум',
            availableSizes: ['XS', 'S', 'M'],
            likes: 3421,
            orders: 67
          }
        },
        {
          id: 'chic-2',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '4',
            name: 'Дизайнерская сумка из экокожи',
            price: '420 000',
            currency: 'сум',
            availableSizes: ['One Size'],
            likes: 756,
            orders: 123
          }
        }
      ]
    },
    {
      storeId: 'aura',
      storeName: 'Aura',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face',
      items: [
        {
          id: 'aura-1',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '6',
            name: 'Туфли премиум класса',
            price: '380 000',
            currency: 'сум',
            availableSizes: ['36', '37', '38', '39', '40'],
            likes: 1089,
            orders: 94
          }
        }
      ]
    },
    {
      storeId: 'ozbe',
      storeName: 'OZBE',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop&crop=face',
      items: [
        {
          id: 'ozbe-1',
          type: 'image',
          src: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=700&fit=crop',
          durationMs: 5000,
          product: {
            id: '12',
            name: 'Базовая футболка Premium Cotton',
            price: '85 000',
            currency: 'сум',
            availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
            likes: 567,
            orders: 234
          }
        }
      ]
    }
  ];

  const stores = [
    { id: 'favorites', name: '+ Избранные', avatar: '⭐', hasStory: false, isSpecial: true },
    { id: 'urban', name: 'Urban', avatar: '🏙️', hasStory: true },
    { id: 'nova', name: 'Nova', avatar: '✨', hasStory: true },
    { id: 'chic', name: 'Chic', avatar: '💅', hasStory: true },
    { id: 'aura', name: 'Aura', avatar: '🌟', hasStory: true },
    { id: 'pink', name: 'Pink', avatar: '🌸', hasStory: false },
    { id: 'ozbe', name: 'OZBE', avatar: '🇺🇿', hasStory: true }
  ];

  // Скидки - Compact cards for horizontal scroll
  const saleProducts = [
    {
      id: '1',
      name: 'Стильная куртка премиум качества',
      price: 280000,
      originalPrice: 400000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=300&h=360&fit=crop',
      store: { id: 'urban', name: 'Urban', avatar: '🏙️' }
    },
    {
      id: '2',
      name: 'Летнее платье в стиле бохо',
      price: 210000,
      originalPrice: 300000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=300&h=360&fit=crop',
      store: { id: 'pink', name: 'Pink', avatar: '🌸' }
    },
    {
      id: '3',
      name: 'Спортивные кроссовки Nike',
      price: 315000,
      originalPrice: 450000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300&h=360&fit=crop',
      store: { id: 'nova', name: 'Nova', avatar: '✨' }
    },
    {
      id: '4',
      name: 'Дизайнерская сумка из экокожи',
      price: 420000,
      originalPrice: 600000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=300&h=360&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' }
    },
    {
      id: '5',
      name: 'Джинсы skinny fit',
      price: 175000,
      originalPrice: 250000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=300&h=360&fit=crop',
      store: { id: 'urban', name: 'Urban', avatar: '🏙️' }
    },
    {
      id: '6',
      name: 'Блузка из шелка',
      price: 140000,
      originalPrice: 200000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=300&h=360&fit=crop',
      store: { id: 'pink', name: 'Pink', avatar: '🌸' }
    },
    {
      id: '7',
      name: 'Зимние ботинки',
      price: 385000,
      originalPrice: 550000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=300&h=360&fit=crop',
      store: { id: 'aura', name: 'Aura', avatar: '🌟' }
    },
    {
      id: '8',
      name: 'Рюкзак для путешествий',
      price: 245000,
      originalPrice: 350000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=360&fit=crop',
      store: { id: 'nova', name: 'Nova', avatar: '✨' }
    },
    {
      id: '9',
      name: 'Кардиган оверсайз',
      price: 315000,
      originalPrice: 450000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=300&h=360&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' }
    },
    {
      id: '10',
      name: 'Солнцезащитные очки',
      price: 105000,
      originalPrice: 150000,
      discount: 30,
      image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=300&h=360&fit=crop',
      store: { id: 'aura', name: 'Aura', avatar: '🌟' }
    }
  ];

  // Хит сезона 2025 - Same compact style as Скидки
  const hitProducts = [
    {
      id: 'h1',
      name: 'Эксклюзивное вечернее платье',
      price: 850000,
      image: 'https://images.unsplash.com/photo-1566479179817-0dcc6b11d8b5?w=300&h=360&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' }
    },
    {
      id: 'h2',
      name: 'Дизайнерские туфли лодочки',
      price: 640000,
      image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=300&h=360&fit=crop',
      store: { id: 'aura', name: 'Aura', avatar: '🌟' }
    },
    {
      id: 'h3',
      name: 'Трендовый костюм оверсайз',
      price: 920000,
      image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=300&h=360&fit=crop',
      store: { id: 'urban', name: 'Urban', avatar: '🏙️' }
    },
    {
      id: 'h4',
      name: 'Кожаная куртка-косуха',
      price: 780000,
      image: 'https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?w=300&h=360&fit=crop',
      store: { id: 'nova', name: 'Nova', avatar: '✨' }
    },
    {
      id: 'h5',
      name: 'Шерстяное пальто макси',
      price: 1250000,
      image: 'https://images.unsplash.com/photo-1544441893-675973e31985?w=300&h=360&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' }
    },
    {
      id: 'h6',
      name: 'Кроссовки лимитированная серия',
      price: 890000,
      image: 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=300&h=360&fit=crop',
      store: { id: 'urban', name: 'Urban', avatar: '🏙️' }
    },
    {
      id: 'h7',
      name: 'Шелковый шарф премиум',
      price: 320000,
      image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=300&h=360&fit=crop',
      store: { id: 'pink', name: 'Pink', avatar: '🌸' }
    },
    {
      id: 'h8',
      name: 'Часы швейцарские',
      price: 2400000,
      image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=300&h=360&fit=crop',
      store: { id: 'aura', name: 'Aura', avatar: '🌟' }
    },
    {
      id: 'h9',
      name: 'Джемпер кашемировый',
      price: 680000,
      image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=300&h=360&fit=crop',
      store: { id: 'nova', name: 'Nova', avatar: '✨' }
    },
    {
      id: 'h10',
      name: 'Сапоги на каблуке',
      price: 520000,
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=300&h=360&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' }
    }
  ];

  // Рекомендации вам - 2-column grid
  const recommendedProducts = [
    {
      id: '8',
      name: 'Элегантное платье миди с поясом',
      price: 450000,
      image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop',
      store: { id: 'urban', name: 'Urban', avatar: '🏙️' },
      rating: 4.8
    },
    {
      id: '9',
      name: 'Кожаные ботинки премиум',
      price: 520000,
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
      store: { id: 'nova', name: 'Nova', avatar: '✨' },
      rating: 4.9
    },
    {
      id: '10',
      name: 'Дизайнерская сумка кросс-боди',
      price: 680000,
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' },
      rating: 4.7
    },
    {
      id: '11',
      name: 'Трендовые кроссовки унисекс',
      price: 390000,
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
      store: { id: 'aura', name: 'Aura', avatar: '🌟' },
      rating: 4.6
    }
  ];

  // Популярные - 2-column grid
  const popularProducts = [
    {
      id: '12',
      name: 'Повседневная футболка премиум',
      price: 150000,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
      store: { id: 'ozbe', name: 'OZBE', avatar: '🇺🇿' },
      rating: 4.5
    },
    {
      id: '13',
      name: 'Удобные джинсы слим фит',
      price: 320000,
      image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop',
      store: { id: 'urban', name: 'Urban', avatar: '🏙️' },
      rating: 4.4
    },
    {
      id: '14',
      name: 'Стильная блуза с рукавами',
      price: 280000,
      image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop',
      store: { id: 'pink', name: 'Pink', avatar: '🌸' },
      rating: 4.7
    },
    {
      id: '15',
      name: 'Модные кеды белые классик',
      price: 240000,
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
      store: { id: 'nova', name: 'Nova', avatar: '✨' },
      rating: 4.3
    },
    {
      id: '16',
      name: 'Весенняя куртка бомбер',
      price: 380000,
      image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop',
      store: { id: 'chic', name: 'Chic', avatar: '💅' },
      rating: 4.6
    },
    {
      id: '17',
      name: 'Юбка плиссе миди длина',
      price: 190000,
      image: 'https://images.unsplash.com/photo-1583496661160-fb5886a13d4e?w=400&h=400&fit=crop',
      store: { id: 'aura', name: 'Aura', avatar: '����' },
      rating: 4.8
    }
  ];

  const formatPrice = (price: number) => {
    return `${price.toLocaleString()} сум`;
  };

  const handleStoryClick = (storeId: string) => {
    // Find the store in stories data and open viewer
    const storeIndex = storiesData.findIndex(store => store.storeId === storeId);
    if (storeIndex !== -1) {
      setStoryViewer({
        isOpen: true,
        storeIndex,
        itemIndex: 0
      });
    }
  };

  const handleStoryViewerClose = () => {
    setStoryViewer(prev => ({ ...prev, isOpen: false }));
  };

  const handleStoryProductClick = (productId: string) => {
    handleStoryViewerClose();
    onProductClick(productId);
  };

  const handleStoryStoreClick = (storeId: string) => {
    handleStoryViewerClose();
    // Navigate to store page
    console.log('Navigate to store:', storeId);
  };

  const handleStoryAddToCart = (productId: string) => {
    console.log('Add to cart from story:', productId);
    // Show success toast or animation
  };

  const handleSeeAll = (section: string) => {
    console.log('See all clicked for:', section);
  };

  const handleLikeToggle = (productId: string) => {
    console.log('Like toggled:', productId);
  };

  const handleQuickAdd = (productId: string) => {
    console.log('Cart clicked:', productId);
  };

  const handleStoreTap = (storeId: string) => {
    console.log('Store tapped:', storeId);
  };

  const handlePhotoSearchClick = () => {
    setIsPhotoSearchOpen(true);
  };

  const handlePhotoSearchClose = () => {
    setIsPhotoSearchOpen(false);
  };

  return (
    <div className="h-full flex flex-col bg-luma-bg-0">
      {/* Fixed Header */}
      <div className="flex-shrink-0 bg-luma-surface-0 px-4 pt-12 pb-4 shadow-luma-soft">
        <div className="flex items-center justify-between mb-[14px] mt-[5px] mr-[0px] ml-[0px]">
          {/* Notifications */}
          <div className="relative">
            <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-luma-primary-200 transition-colors" onClick={onNotificationsClick}>
              <Bell className="w-6 h-6 text-luma-primary-600" />
            </button>
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-luma-danger-600 rounded-full flex items-center justify-center">
              <span className="text-xs text-white font-medium">3</span>
            </div>
          </div>

          {/* luma Logo */}
          <h1 className="text-xl font-bold text-luma-primary-600 tracking-wide" style={{ fontFamily: 'Open Sans, sans-serif' }}>luma</h1>

          {/* Favorites Icon */}
          <div className="relative">
            <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-luma-primary-200 transition-colors" onClick={() => onFavoritesClick?.()}>
              <Heart className="w-6 h-6 text-luma-primary-600" />
            </button>
          </div>


        </div>

        {/* Search Bar */}
        <div className="relative">
          <Input
            type="text"
            placeholder="Поиск товаров, брендов, магазинов..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onClick={onSearchClick}
            className="bg-luma-surface-0 border-luma-border-200 focus:border-luma-primary-600 text-base pr-12 rounded-luma"
            readOnly
          />
          <button
            onClick={handlePhotoSearchClick}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-full hover:bg-luma-primary-200 transition-colors"
          >
            <Camera className="w-5 h-5 text-luma-primary-600" />
          </button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto" style={{ paddingBottom: '104px' }}>
        {/* Stories Section */}
        <div className="py-6 mx-[10px] my-[0px] m-[0px] px-[10px] px-[20px] py-[21px]">
          <div className="flex gap-4 overflow-x-auto scrollbar-hide mx-[-5px] my-[0px] mx-[-10px]">
            {stores.map((store) => (
              <button
                key={store.id}
                onClick={() => handleStoryClick(store.id)}
                className="flex-shrink-0 flex flex-col items-center gap-2 w-14 mx-[-1px] my-[0px] mt-[0px] mr-[0px] mb-[0px] ml-[5px]"
              >
                <div className={`w-14 h-14 rounded-full flex items-center justify-center text-lg ${
                  store.isSpecial 
                    ? 'bg-luma-primary-200 border-2 border-dashed border-luma-primary-600'
                    : store.hasStory
                      ? 'bg-luma-surface-0 border-2 border-luma-primary-500 shadow-luma-soft'
                      : 'bg-luma-surface-0 border-2 border-luma-border-200 shadow-luma-soft'
                }`}>
                  {store.avatar}
                </div>
                <span className="text-xs text-luma-text-900 text-center leading-tight">
                  {store.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Store Promo Slider */}
        <div className="px-4 mb-4">
          <StorePromoSlider onSlideClick={(slide) => console.log('Promo clicked:', slide)} />
        </div>

        {/* AI Look Callout */}
        <div className="px-4 mb-6">
          <MagicCallout onClick={() => onAILookClick?.()} />
        </div>

        {/* 1. Скидки Section - First content section */}
        <div className="mb-[21px] mt-[0px] mr-[10px] ml-[10px]">
          <div className="flex items-center justify-between mb-4 px-4">
            <h2 className="text-xl font-bold text-luma-text-900">Скидки</h2>
            <button 
              onClick={() => handleSeeAll('sales')}
              className="flex items-center gap-1 text-sm text-luma-primary-600 font-medium hover:text-luma-primary-500"
            >
              Смотреть всё
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <ProductCarousel
            products={saleProducts}
            onProductClick={onProductClick}
            onStoreClick={(storeId) => console.log('Store clicked:', storeId)}
            onAddToCart={handleQuickAdd}
          />
        </div>

        {/* 2. Хит сезона 2025 Section */}
        <div className="mb-[21px] mt-[0px] mr-[10px] ml-[10px]">
          <div className="flex items-center justify-between mb-4 px-4">
            <h2 className="text-xl font-bold text-luma-text-900">Хит сезона 2025</h2>
            <button 
              onClick={() => handleSeeAll('hits')}
              className="flex items-center gap-1 text-sm text-luma-primary-600 font-medium hover:text-luma-primary-500"
            >
              Смотреть всё
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <ProductCarousel
            products={hitProducts}
            onProductClick={onProductClick}
            onStoreClick={(storeId) => console.log('Store clicked:', storeId)}
            onAddToCart={handleQuickAdd}
          />
        </div>

        {/* 3. Рекомендации вам Section - 2-column grid */}
        <div className="px-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-luma-text-900">Рекомендации вам</h2>
            <button 
              onClick={() => handleSeeAll('recommendations')}
              className="flex items-center gap-1 text-sm text-luma-primary-600 font-medium hover:text-luma-primary-500"
            >
              Смотреть всё
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {recommendedProducts.map((product) => (
              <ProductCardModern
                key={product.id}
                id={product.id}
                title={product.name}
                image={product.image}
                price={product.price}
                originalPrice={product.originalPrice}
                storeName={product.store.name}
                storeIcon={product.store.avatar}
                onProductClick={onProductClick}
                onStoreClick={() => console.log('Store clicked:', product.store.id)}
                onAddToCart={handleQuickAdd}
              />
            ))}
          </div>
        </div>

        {/* 4. Популярные Section - 2-column grid (infinite) */}
        <div className="px-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-luma-text-900">Популярные</h2>
            <button 
              onClick={() => handleSeeAll('popular')}
              className="flex items-center gap-1 text-sm text-luma-primary-600 font-medium hover:text-luma-primary-500"
            >
              Смотреть всё
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {popularProducts.map((product) => (
              <ProductCardModern
                key={product.id}
                id={product.id}
                title={product.name}
                image={product.image}
                price={product.price}
                originalPrice={product.originalPrice}
                storeName={product.store.name}
                storeIcon={product.store.avatar}
                onProductClick={onProductClick}
                onStoreClick={() => console.log('Store clicked:', product.store.id)}
                onAddToCart={handleQuickAdd}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Floating Navigation Bar */}
      <FloatingBottomNav 
        activeTab={activeTab}
        onTabChange={onTabChange}
        cartItemCount={3}
      />

      {/* Story Viewer Overlay */}
      {storyViewer.isOpen && (
        <StoryViewer
          stories={storiesData}
          initialStoreIndex={storyViewer.storeIndex}
          initialItemIndex={storyViewer.itemIndex}
          onClose={handleStoryViewerClose}
          onAddToCart={handleStoryAddToCart}
          onViewProduct={handleStoryProductClick}
          onViewStore={handleStoryStoreClick}
        />
      )}

      {/* Photo Search Modal */}
      <PhotoSearchModal
        isOpen={isPhotoSearchOpen}
        onClose={handlePhotoSearchClose}
      />
    </div>
  );
}