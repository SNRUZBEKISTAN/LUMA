import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { ProductImageContainer } from './ProductImageContainer';
import { PriceTag } from './PriceTag';

export interface ProductCardCompactProps {
  // Data
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  image: string;
  storeName?: string;
  storeIcon?: string;
  
  // Event handlers
  onProductClick?: (id: string) => void;
  onStoreClick?: (storeId: string) => void;
  onAddToCart?: (id: string) => void;
}

export function ProductCardCompact({
  id,
  title,
  price,
  originalPrice,
  image,
  storeName,
  storeIcon = '🏪',
  onProductClick,
  onStoreClick,
  onAddToCart
}: ProductCardCompactProps) {
  const [showCartButton, setShowCartButton] = React.useState(false);

  return (
    <div 
      className="group relative bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-150 ease-in-out hover:scale-[1.02] cursor-pointer w-full"
      onClick={() => onProductClick?.(id)}
      onMouseEnter={() => setShowCartButton(true)}
      onMouseLeave={() => setShowCartButton(false)}
    >
      {/* Изображение товара - aspect-ratio 1:1 согласно ТЗ */}
      <div className="relative">
        <ProductImageContainer 
          src={image} 
          alt={title}
          className="w-full aspect-square object-cover rounded-t-xl shadow-sm"
        />
        
        {/* Кнопка корзины при hover - появляется справа внизу согласно ТЗ */}
        {showCartButton && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart?.(id);
            }}
            className="absolute bottom-2 right-2 bg-luma-primary-600 text-white p-2 rounded-lg shadow-lg transform scale-0 group-hover:scale-100 transition-transform duration-200 hover:bg-luma-primary-700"
          >
            <ShoppingCart className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Контент - padding 12px согласно ТЗ */}
      <div className="p-3 space-y-2 mt-[0px] mr-[0px] mb-[5px] ml-[0px]">
        {/* Магазин - text-xs, text-muted-foreground, под фото согласно ТЗ */}
        {storeName && (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onStoreClick?.(id);
            }}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-luma-primary-600 transition-colors w-full justify-start"
          >
            <span className="text-xs">{storeIcon}</span>
            <span className="truncate">{storeName}</span>
          </button>
        )}

        {/* Название товара - text-sm, font-medium, line-clamp-2, под магазином согласно ТЗ */}
        <h3 className="text-sm font-medium text-luma-text-900 line-clamp-2 leading-tight">
          {title}
        </h3>

        {/* Цена - в отдельной области согласно ТЗ */}
        <div className="pt-1">
          <PriceTag 
            price={price}
            originalPrice={originalPrice}
            size="sm"
            variant="compact"
          />
        </div>
      </div>
    </div>
  );
}