# Google OAuth Integration для LUMA

## Обзор

Реализована полная интеграция с Google OAuth для безопасной авторизации пользователей в приложении LUMA. Пользователи могут входить одним кликом через свой Google аккаунт без необходимости создавать отдельные пароли.

## Функциональность

### ✅ Что реализовано:

- **Google Identity Services (GSI)** - современная библиотека от Google
- **JWT Token Decoding** - безопасное извлечение пользовательских данных
- **Роли пользователей** - поддержка покупателей и продавцов
- **Fallback режим** - демо авторизация если OAuth не настроен
- **UI компоненты** - красивая кнопка Google с иконкой
- **Руководство по настройке** - встроенный помощник в приложении
- **Error handling** - обработка ошибок авторизации
- **Token management** - сохранение и проверка токенов

### 🎯 Как это работает:

1. **Пользователь кликает кнопку Google** в форме авторизации
2. **Проверяется Client ID** - если не настроен, показывается руководство
3. **Открывается Google Auth popup** - пользователь выбирает аккаунт
4. **Получаем JWT token** - Google возвращает подписанный токен
5. **Декодируем данные** - извлекаем email, имя, картинку
6. **Создаем LUMA пользователя** - преобразуем в формат приложения
7. **Сохраняем токен** - для будущих запросов
8. **Завершаем авторизацию** - пользователь входит в приложение

## Настройка

### 1. Google Cloud Console

1. Перейдите в [Google Cloud Console](https://console.cloud.google.com/)
2. Создайте новый проект или выберите существующий
3. Включите **Google Identity Services API**
4. Перейдите в **APIs & Services > Credentials**
5. Нажмите **Create Credentials > OAuth 2.0 Client ID**
6. Выберите **Web application**
7. Добавьте домены в **Authorized JavaScript origins**:
   - `http://localhost:3000` (для разработки)
   - `https://yourdomain.com` (для продакшена)

### 2. Environment Variables

Создайте файл `.env` в корне проекта:

```env
REACT_APP_GOOGLE_CLIENT_ID=your_google_client_id_here.apps.googleusercontent.com
```

### 3. Перезапуск приложения

```bash
npm restart
# или
yarn start
```

## Безопасность

### ⚠️ Важные моменты:

- **Client ID не секретный** - можно использовать в frontend коде
- **JWT токены верифицируются** - но только для клиентской стороны
- **В продакшене** - дополнительно верифицируйте токены на бэкенде
- **HTTPS обязательно** - для продакшн доменов
- **Не храните секреты** - в localStorage только публичные данные

### 🔒 Что защищено:

- Токены имеют срок действия (1 час)
- Автоматическая очистка истекших токенов
- Проверка целостности JWT
- Защита от CSRF атак (встроенная в GSI)

## Структура файлов

```
/components/
  ├── AuthLite.tsx              # Основная форма авторизации
  ├── GoogleAuthProvider.tsx    # Provider для Google SDK
  └── GoogleSetupGuide.tsx     # Руководство по настройке

/utils/
  └── googleAuth.ts            # Утилиты для работы с Google OAuth

/.env.example                  # Пример конфигурации
/docs/GoogleOAuth.md          # Эта документация
```

## API Компонентов

### GoogleAuthProvider

```tsx
<GoogleAuthProvider onSuccess={handleSuccess} onError={handleError}>
  {children}
</GoogleAuthProvider>
```

**Props:**
- `onSuccess: (credentialResponse) => void` - успешная авторизация
- `onError: () => void` - ошибка авторизации

### Утилиты googleAuth.ts

```tsx
import {
  decodeGoogleJWT,          // Декодирование JWT токена
  createLumaUserFromGoogle, // Создание LUMA пользователя
  saveGoogleToken,          // Сохранение токена
  getGoogleToken,           // Получение токена
  clearGoogleToken,         // Очистка токена
  isGoogleAuthenticated     // Проверка авторизации
} from '../utils/googleAuth';
```

## Демо режим

Если Google OAuth не настроен:

- **Показывается руководство** по настройке при клике на кнопку Google
- **Fallback авторизация** - создается демо пользователь с данными Google
- **Работает весь функционал** - можно тестировать приложение

## Troubleshooting

### Проблемы и решения:

**1. "Google SDK не загружается"**
- Проверьте интернет соединение
- Убедитесь что нет блокировщиков рекламы
- Проверьте консоль браузера на ошибки

**2. "Client ID не найден"**
- Проверьте файл `.env`
- Убедитесь что переменная начинается с `REACT_APP_`
- Перезапустите development server

**3. "OAuth popup не открывается"**
- Проверьте настройки браузера (блокировка popup)
- Убедитесь что домен добавлен в Google Console
- Проверьте HTTPS для продакшн домена

**4. "Token invalid или expired"**
- Токены действительны 1 час
- Автоматически очищаются при истечении
- Пользователь должен авторизоваться заново

## Расширения

### Возможные улучшения:

- **Refresh токены** - для автоматического обновления
- **Backend верификация** - проверка токенов на сервере  
- **Multi-domain support** - поддержка нескольких доменов
- **Analytics integration** - отслеживание авторизаций
- **Custom scopes** - запрос дополнительных разрешений

## Поддержка

- **Google Identity Services Docs:** https://developers.google.com/identity/gsi/web
- **JWT.io:** https://jwt.io/ (для отладки токенов)
- **Google Cloud Console:** https://console.cloud.google.com/